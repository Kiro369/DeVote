# DeVote
An Electronic Voting Project using Distributed Ledger Technology (DLT)
