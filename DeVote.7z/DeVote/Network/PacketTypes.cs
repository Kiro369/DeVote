﻿namespace DeVote.Network
{
    public enum PacketTypes : short
    {
        None = 0,
        Test = 1,
    }
}
