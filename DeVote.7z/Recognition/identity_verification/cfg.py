'''
global vars

'''

numbers_of_cameras = 1
video_stream_camera = 1
num_of_frames = 5
delay_time = 0
tolerance = 0.6


